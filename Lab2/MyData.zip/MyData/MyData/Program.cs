﻿using MyData;

MyData.MyData.info();
