﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Sockets;
using System.Net;
using System.Text;
using System.Threading.Tasks;

namespace MyData
{
    public class MyData
    {
        public static void info()
        {
            Console.WriteLine("Aleksandra Wolska, 251810");
            Console.WriteLine("Szymon Lopuszynski, 260454");
            DateTime date = DateTime.Now;
            Console.WriteLine(date.ToString("M")+ ", " + date.ToString("T"));
            Console.WriteLine(Environment.Version);
            Console.WriteLine(Environment.UserName);
            Console.WriteLine(Environment.OSVersion.ToString());
            var host = Dns.GetHostEntry(Dns.GetHostName());
            foreach (var ip in host.AddressList)
            {
                if (ip.AddressFamily == AddressFamily.InterNetwork)
                {
                    Console.WriteLine(ip.ToString());
                }
            }
        }

    }
}
