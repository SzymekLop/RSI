﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.ServiceModel;
using System.ServiceModel.Description;
using System.Text;
using System.Threading.Tasks;
using WcfServiceMathLibrary;

namespace WcfMathService
{
    internal class Program
    {
        static void Main(string[] args)
        {
 
            Uri baseAddress = new Uri("http://localhost:2115/MyCalculator"); 
            ServiceHost myHost = new ServiceHost(typeof(MyCalculator), baseAddress); 

            BasicHttpBinding myBinding = new BasicHttpBinding(); 
            ServiceEndpoint endpoint1 = myHost.AddServiceEndpoint ( typeof(ICalculator), myBinding, "endpoint1");

            WSHttpBinding binding2 = new WSHttpBinding();
            binding2.Security.Mode = SecurityMode.None;
            ServiceEndpoint endpoint2 = myHost.AddServiceEndpoint(typeof(ICalculator), binding2, "endpoint2");

            ServiceMetadataBehavior smb = new ServiceMetadataBehavior(); 
            smb.HttpGetEnabled = true; 
            myHost.Description.Behaviors.Add(smb); 

            try {
                Console.WriteLine("---> Endpointy:");
                printEndpoint(endpoint1);
                printEndpoint(endpoint2);

                myHost.Open();
                Console.WriteLine("Service is started and running.");
                Console.WriteLine("Press <ENTER> to STOP service...");
                Console.WriteLine();
                Console.ReadLine();
                myHost.Close(); 
            } catch (CommunicationException ce) { 
                Console.WriteLine("Wystapil wyjatek: {0}", ce.Message); 
                myHost.Abort(); 
            } 
            
        }

        static void printEndpoint(ServiceEndpoint endpoint)
        {
            Console.WriteLine("Service endpoint: {0}", endpoint.Name);
            Console.WriteLine("Binding: {0}", endpoint.Binding.ToString());
            Console.WriteLine("ListenUri: {0}", endpoint.ListenUri.ToString());
        }
    }
}
