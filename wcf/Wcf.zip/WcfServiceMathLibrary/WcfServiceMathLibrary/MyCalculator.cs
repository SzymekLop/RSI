﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Text;
using System.Threading.Tasks;

namespace WcfServiceMathLibrary
{
    // UWAGA: możesz użyć polecenia „Zmień nazwę” w menu „Refaktoryzuj”, aby zmienić nazwę klasy „Service1” w kodzie i pliku konfiguracji.
    [ServiceBehavior(InstanceContextMode = InstanceContextMode.Single,
    ConcurrencyMode = ConcurrencyMode.Multiple)]
    public class MyCalculator : ICalculator
    {
        public int iAdd(int n1, int n2)
        {
            Console.WriteLine($"iAdd({n1}, {n2})");
            try
            {
                checked {
                    return n1 + n2; 
                }
            }
            catch (OverflowException e)
            {
                throw new FaultException<OverflowException>(e, new FaultReason($"Overflow when adding {n1} and {n2}"));
            }
        }

        public int iSub(int n1, int n2)
        {
            Console.WriteLine($"iSub({n1}, {n2})");
            try
            {
                checked
                {
                    return n1 - n2;
                }
            }
            catch (OverflowException e)
            {
                throw new FaultException<OverflowException>(e, new FaultReason($"Overflow when subtractiog {n1} and {n2}"));
            }
        }

        public int iMul(int n1, int n2)
        {
            Console.WriteLine($"iMul({n1}, {n2})");
            try
            {
                checked
                {
                    return n1 * n2;
                }
            }
            catch (OverflowException e)
            {
                throw new FaultException<OverflowException>(e, new FaultReason($"Overflow when multipling {n1} and {n2}"));
            }
        }

        public int iDiv(int n1, int n2)
        {
            Console.WriteLine($"iDiv({n1}, {n2})");
            try
            {
                checked
                {
                    return n1 / n2;
                }
            }
            catch (DivideByZeroException e)
            {
                throw new FaultException<DivideByZeroException>(e, new FaultReason($"You can not divide by zero"));
            }
        }

        public int iMod(int n1, int n2)
        {
            Console.WriteLine($"iMod({n1}, {n2})");
            try
            {
                checked
                {
                    return n1 % n2;
                }
            }
            catch (DivideByZeroException e)
            {
                throw new FaultException<DivideByZeroException>(e, new FaultReason($"You can not modulo by zero"));
            }
        }

        public async Task<int> HMul(int n1, int n2)
        {
            Console.WriteLine($"HMul({n1}, {n2})");
            try
            {
                checked
                {
                    await Task.Delay(5000);
                    return n1 * n2;
                }
            }
            catch (OverflowException e)
            {
                throw new FaultException<OverflowException>(e, new FaultReason($"Overflow when multipling {n1} and {n2}"));
            }
        }

        public async Task<(int, int)> CountAndMaxPrimesInRangeAsync(int n1, int n2)
        {
            Console.WriteLine($"CountAndMaxPrimesInRangeAsync({n1}, {n2})");

            int count = 0;
            int max = n1;

            await Task.Run(() =>
            {
                for (int i = n1; i < n2; i++)
                {
                    if (isPrime(i))
                    {
                        count++;
                        max = i;
                    }
                }
            });
            return (count, max);
        }

        private bool isPrime(int n)
        {
            if (n <= 1) 
            {
                return false;
            }
            for (int i = 2; i < Math.Sqrt(n); i++) 
            { 
                if (n % i == 0) 
                {
                    return false;
                }
            }
            return true;
        }
    }
}
