﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.ServiceModel.Web;
using System.Text;
using System.Threading.Tasks;

namespace MyWebService
{
    // UWAGA: możesz użyć polecenia „Zmień nazwę” w menu „Refaktoryzuj”, aby zmienić nazwę interfejsu „IService1” w kodzie i pliku konfiguracji.
    [ServiceContract]
    public interface IRestService
    {

        [OperationContract]
        [WebGet(UriTemplate = "/people")] 
        List<Person> getAllXml(); 

        [OperationContract]
        [WebGet(UriTemplate = "/people/{id}", ResponseFormat = WebMessageFormat.Xml)]
        Person getByIdXml(string Id); 

        [OperationContract]
        [WebInvoke(UriTemplate = "/people", Method = "POST", RequestFormat = WebMessageFormat.Xml)] 
        string addXml(Person item);

        [OperationContract]
        [WebInvoke(UriTemplate = "/people{id}", Method = "DELETE")] 
        string deleteXml(string Id);

        [OperationContract]
        [WebInvoke(UriTemplate = "/people{id}", Method = "PUT", RequestFormat = WebMessageFormat.Xml)]
        string updateXml(string Id, Person person);

        [OperationContract]
        [WebGet(UriTemplate = "/people/count")]
        int getAllCountXml();

        [OperationContract]
        [WebGet(UriTemplate = "/json/people", ResponseFormat = WebMessageFormat.Json)]
        List<Person> getAllJson();

        [OperationContract]
        [WebGet(UriTemplate = "/json/people/{id}", ResponseFormat = WebMessageFormat.Json)]
        Person getByIdJson(string Id);

        [OperationContract]
        [WebInvoke(UriTemplate = "/json/people", Method = "POST", RequestFormat = WebMessageFormat.Json, ResponseFormat = WebMessageFormat.Json)]
        string addJson(Person item);

        [OperationContract]
        [WebInvoke(UriTemplate = "/json/people{id}", Method = "DELETE", ResponseFormat = WebMessageFormat.Json)]
        string deleteJson(string Id);

        [OperationContract]
        [WebInvoke(UriTemplate = "/json/people{id}", Method = "PUT", RequestFormat = WebMessageFormat.Json, ResponseFormat = WebMessageFormat.Json)]
        string updateJson(string Id, Person person);

        [OperationContract]
        [WebGet(UriTemplate = "/json/people/count")]
        int getAllCountJson();

    }

    [DataContract]
    public class Person
    {
        [DataMember(Order = 1)]
        public int Id { get; set; }

        [DataMember(Order = 2)]
        public string Name { get; set; }

        [DataMember(Order = 3)]
        public int Age { get; set; }

        [DataMember(Order = 4)]
        public string Email { get; set; }

    }
}
